# Projeto TDAH

Este um é um repositorio dedicado a armazenar os arquivos do projeto tcc.

## Comandos Uteis

1. git config --global user.email "externalconnections.pedro@gmail.com"
2. git config --global user.name"ExternalPedro"
3. npm install cookie-parser ejs express express-ejs-layouts express-session firebase
4. npm install autoprefixer concurrently postcss sass tailwindcss --save-dev
